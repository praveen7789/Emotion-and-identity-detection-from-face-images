# FACE RECOGNITION MEETUP ON  1-SEP-2018
> Experience Data Science


[![flyer.jpg](https://s15.postimg.cc/6oef5yl4r/flyer.jpg)](https://www.innomatics.in/)
(https://www.innomatics.in/)


### Requried Libraries to be installed on Python (Anaconda recommended)

- numpy
- pandas
- matplotlib
- sklearn
- scipy

### Computer Vison Libraries for python (Prefered Anaconda)
- dlib   			  
> conda install conda-forge dlib
- opencv   		
> pip install opencv-python
